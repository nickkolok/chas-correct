module.exports = 'dir/a';
