module.exports = require('test-math');
