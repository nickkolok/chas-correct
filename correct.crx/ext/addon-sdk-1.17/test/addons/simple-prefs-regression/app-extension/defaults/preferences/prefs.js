pref("extensions.test-simple-prefs@jetpack.somePreference", "TEST");
pref("extensions.test-simple-prefs@jetpack.myInteger", 8);
pref("extensions.test-simple-prefs@jetpack.myHiddenInt", 5);
