module.exports = 'this is a dummy module';
