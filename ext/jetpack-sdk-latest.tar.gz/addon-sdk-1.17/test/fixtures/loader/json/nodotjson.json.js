module.exports = {
  "filename": "nodotjson.json.js",
  "data": {}
};
