/*
Copyright Nikolay Avdeev aka NickKolok aka Николай Авдеев 2015

Всем привет из снежного Воронежа! 

This file is part of CHAS-CORRECT.

    CHAS-CORRECT is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    CHAS-CORRECT is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CHAS-CORRECT.  If not, see <http://www.gnu.org/licenses/>.

  (Этот файл — часть CHAS-CORRECT.

   CHAS-CORRECT - свободная программа: вы можете перераспространять её и/или
   изменять её на условиях Стандартной общественной лицензии GNU в том виде,
   в каком она была опубликована Фондом свободного программного обеспечения;
   либо версии 3 лицензии, либо (по вашему выбору) любой более поздней
   версии.

   CHAS-CORRECT распространяется в надежде, что она будет полезной,
   но БЕЗО ВСЯКИХ ГАРАНТИЙ; даже без неявной гарантии ТОВАРНОГО ВИДА
   или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ. Подробнее см. в Стандартной
   общественной лицензии GNU.

   Вы должны были получить копию Стандартной общественной лицензии GNU
   вместе с этой программой. Если это не так, см.
   <http://www.gnu.org/licenses/>.)
*/
'use strict';

var precacheVKsoviet={
	' — отправка телеграммы':null,
	' — перенос строки':null,
	' Скачать':null,
	' Скачать альбом':null,
	'Введите имя, название или слово':null,
	'Донести на врага народа':null,
	'Достать старые телеграммы ↑':null,
	'Здесь Вы будете видеть новостную ленту своих товарищей.':null,
	'Здесь будет выводиться история переписки.':null,
	'На связи':null,
	'На этой фотокарточке: undefined':null,
	'Одобряю':null,
	'Пожаловаться':null,
	'Показаны последние новости':null,
	'Показать больше фотокарточек':null,
	'Показать предыдущие новости ↓':null,
	'Показать следующие сообщения ↓':null,
	'Понимаю, но осуждаю':null,
	'Пригласить на видеозвонок':null,
	'Просмотреть подробное досье':null,
	'Разгласить':null,
	'бдит':null,
	'был замечен на следующих фотокарточках:':null,
	'была замечена на следующих фотокарточках:':null,
	'одну минуту назад':null,
	'от имени оргсовета':null,
	'просмотреть предыдущие высказывания':null,
	'сегодня':null,
	'час назад':null,
/*
	'':null,
	'':null,
	'':null,
	'':null,
	'':null,
	'':null,
	'':null,
	'':null,
	'':null,
	'':null,
*/
};
